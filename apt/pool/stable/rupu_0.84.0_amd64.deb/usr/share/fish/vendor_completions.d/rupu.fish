# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rupu_global_optspecs
	string join \n format= absolute all-columns max-open-files= h/help V/version
end

function __fish_rupu_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_rupu_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_rupu_using_subcommand
	set -l cmd (__fish_rupu_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c rupu -n "__fish_rupu_needs_command" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_needs_command" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_needs_command" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_needs_command" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_needs_command" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_needs_command" -s V -l version -d 'Print version'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "run" -d 'One-shot agent run, or pause/resume a run by id'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "agent" -d 'Manage agents'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "workflow" -d 'Manage workflows'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "agentiflow" -d 'Run goal-directed agent fleets (agentiflows)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "message" -d 'Talk to a run as its operator: its message space\'s messages, participants, and sending into it'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "autoflow" -d 'Run autonomous workflows against persistent issue state'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "transcript" -d 'Browse transcripts'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "config" -d 'Get / set configuration values'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "customer" -d 'Customers: group projects under a customer with its own config layer'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "ui" -d 'Manage UI themes and palette imports'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "cleanup" -d 'Prune archived local sessions and transcripts'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "auth" -d 'Manage provider credentials'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "models" -d 'List or refresh available models'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "netflow" -d 'Manage per-run netflow ledgers (retention / pruning)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "repos" -d 'SCM repository operations'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "scm" -d 'Multi-account SCM routing: rules and the account roster'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "session" -d 'Persistent agent sessions'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "issues" -d 'Issue-tracker operations (list / show / run a workflow)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "init" -d 'Bootstrap a new rupu project (`.rupu/agents`, `.rupu/workflows`, `.rupu/netflow`, config)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "mcp" -d 'MCP server operations'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "coverage" -d 'Inspect agentic coverage ledgers and concern catalogs'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "fleet" -d 'Install the stock security-assessment fleet (the generic agents + workflows the built-in engagement profiles name) into `~/.rupu`'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "skill" -d 'Agent Skills: install, update, list, show and validate SKILL.md skills'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "findings" -d 'Finding reports: the embedded report schema, and report exports'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "cron" -d 'Schedule-driven workflow firing (designed for system cron)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "webhook" -d 'Webhook receiver for event-triggered workflows (GitHub / GitLab)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "cp" -d 'Control-plane HTTP server for the rupu web UI'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "usage" -d 'Aggregate token spend across persisted transcripts'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "watch" -d 'Re-attach to an existing run'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "completions" -d 'Generate or install shell-completion scripts'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "host" -d 'Manage named rupu-cp hosts (add / list / remove)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "node" -d 'Dial-home tunnel agent + node enrollment'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "update" -d 'Download and install the latest release for the configured channel'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "man" -d 'Render the man page to stdout'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "__apply-update" -d 'Internal: privileged install step invoked by `rupu update` via `sudo` when the install directory isn\'t user-writable'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "__workspace" -d 'Internal: remote workspace stage/collect helper (SSH workspace sync)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "__skills" -d 'Internal: cache skills shipped to this host (placed-unit skills)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "__features" -d 'Internal: print this build\'s host features (SSH capability probe)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "__message" -d 'Internal: read or write a run\'s message space as its operator (SSH transport); the protocol is `cmd::message::HelperAction`\'s'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "__findings" -d 'Internal: stream a finding artifact from this host\'s store (SSH artifact pull)'
complete -c rupu -n "__fish_rupu_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand run" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -f -a "list" -d 'List all available agents (global + project)'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -f -a "show" -d 'Print an agent\'s frontmatter and body'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -f -a "edit" -d 'Open an agent file in `$VISUAL` / `$EDITOR`. Validates the frontmatter on save (warn-only)'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -f -a "validate" -d 'Check agent files: each must parse and its `tools:` must name known tools (an unknown name is a load error). Checks every file in the global and project agent dirs with `--all`, shadowed ones included. Exits nonzero when any check fails'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -f -a "create" -d 'Scaffold a new agent file, then open it for editing. Prompts interactively for scope and name when omitted. With `--describe`, a model drafts the definition before you review it'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and not __fish_seen_subcommand_from list show edit validate create help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from list" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env, `[ui].color = "never"` in config)'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -l theme -d 'syntect theme name. Default: `base16-ocean.dark`' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env var)'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -l pager -d 'Force pager. Default: page when stdout is a tty'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -l no-pager -d 'Disable pager'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from edit" -l scope -d 'Force the project shadow (`.rupu/agents/<name>.md`) or the global file (`<global>/agents/<name>.md`). Default: prefer project if it exists, else global' -r -f -a "global\t''
project\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from edit" -l editor -d 'Override the editor (e.g. `--editor "code --wait"`). Default: `$VISUAL` then `$EDITOR` then `vi`' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from edit" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from edit" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from edit" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from edit" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from edit" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from validate" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from validate" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from validate" -l all -d 'Check every agent file in both layers'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from validate" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from validate" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from validate" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l scope -d 'Target scope (`global` or `project`). Prompts when omitted' -r -f -a "global\t''
project\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l editor -d 'Override the editor (e.g. `--editor "code --wait"`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l describe -d 'Natural-language description — a model drafts the agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l gen-provider -d 'Provider for generation (default: first authenticated)' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l gen-model -d 'Model for generation (default: provider\'s default)' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l host -d 'Host to create on (only `local` available today)' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from create" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "list" -d 'List all available agents (global + project)'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "show" -d 'Print an agent\'s frontmatter and body'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "edit" -d 'Open an agent file in `$VISUAL` / `$EDITOR`. Validates the frontmatter on save (warn-only)'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "validate" -d 'Check agent files: each must parse and its `tools:` must name known tools (an unknown name is a load error). Checks every file in the global and project agent dirs with `--all`, shadowed ones included. Exits nonzero when any check fails'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "create" -d 'Scaffold a new agent file, then open it for editing. Prompts interactively for scope and name when omitted. With `--describe`, a model drafts the definition before you review it'
complete -c rupu -n "__fish_rupu_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "list" -d 'List all workflows (global + project)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "show" -d 'Inspect a workflow definition'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "edit" -d 'Open a workflow file in `$VISUAL` / `$EDITOR`. Validates the YAML on save (warn-only)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "create" -d 'Scaffold a new workflow YAML from a template, then open it for editing. Prompts interactively for scope and name when omitted. With `--describe`, a model drafts the definition before you review it'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "run" -d 'Run a workflow'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "runs" -d 'List recent workflow runs from the persistent run-store (`<global>/runs/`). Newest first'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "show-run" -d 'Inspect one persisted run: status, inputs, per-step transcript pointers'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "approve" -d 'Approve a paused run and resume execution from the awaited step. The run must be in `awaiting_approval` status'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "reject" -d 'Reject a paused run. Marks it `rejected`; no further steps dispatch'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "cancel" -d 'Cancel a running workflow run'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "pause" -d 'Cooperatively pause a running workflow run at its next safe boundary, leaving it non-terminal and resumable via `rupu workflow resume`'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "resume" -d 'Resume a failed/cancelled run, re-running only the agent runs that didn\'t succeed. An agent run the interrupted process left mid-flight is picked up where it stopped (or its finished answer reused) rather than started over'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "archive-run" -d 'Archive a terminal run (move it out of the active list; reversible)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "restore-run" -d 'Restore an archived run back to the active list'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "delete-run" -d 'Permanently delete a run and its transcripts. Requires `--force`'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and not __fish_seen_subcommand_from list show edit create run runs show-run approve reject cancel pause resume archive-run restore-run delete-run help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l view -d 'Human snapshot density (`focused` | `compact` | `full`)' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l theme -d 'syntect theme name. Default: `base16-ocean.dark`' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env var)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l pager -d 'Force pager. Default: page when stdout is a tty'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l no-pager -d 'Disable pager'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from edit" -l scope -d 'Force the project shadow (`.rupu/workflows/<name>.yaml`) or the global file (`<global>/workflows/<name>.yaml`). Default: prefer project if it exists, else global' -r -f -a "global\t''
project\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from edit" -l editor -d 'Override the editor (e.g. `--editor "code --wait"`). Default: `$VISUAL` then `$EDITOR` then `vi`' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from edit" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from edit" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from edit" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from edit" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from edit" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l scope -d 'Target scope (`global` or `project`). Prompts when omitted' -r -f -a "global\t''
project\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l editor -d 'Override the editor (e.g. `--editor "code --wait"`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l describe -d 'Natural-language description — a model drafts the workflow' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l gen-provider -d 'Provider for generation (default: first authenticated)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l gen-model -d 'Model for generation (default: provider\'s default)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l host -d 'Host to create on (only `local` available today)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from create" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l input -d '`KEY=VALUE` template inputs (repeatable)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l mode -d 'Override permission mode (`ask` | `bypass` | `readonly`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l view -d 'Control live output density (`focused` | `full`)' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l run-id -d 'Pre-assign the run id (e.g. so a caller can reference the run before it starts)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l engagement-profile -l engagement-profiles -d 'Engagement profile(s) for this run — the asset domain(s) every step\'s findings are validated against (e.g. `network`, `binary`, or a composite like `pentest`). Repeatable or comma-separated. Empty = the `code` path' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l fleet-run-dir -d 'Run as an agentiflow unit: the agentiflow run dir (`<global>/agentiflows/<id>`). Every step\'s findings and coverage then pool into the agentiflow\'s scope (the run dir\'s name) instead of the workflow\'s own. Set by an agentiflow lead when it launches a workflow unit; not for direct use. Needs `--fleet-participant`' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l fleet-participant -d 'This unit\'s participant id on the agentiflow board. Needs `--fleet-run-dir`. Workflow steps are findings-only (no board tools), so it only pairs with the run dir' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l file -d 'Run a workflow directly from a file path instead of resolving a name from the catalog. The workflow is not added to the catalog' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l workflow-name -d 'The catalog id the launching run looked `--file` up under: the run is named by it instead of the file\'s `name:`. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l codename -d 'The run\'s codename, minted by the run that launched it: its steps are named under it. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l launch-depth -d 'This run\'s launch depth: its launching parent\'s + 1. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l launch-ceiling -d 'The parent\'s permission ceiling. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l parent-run -d 'The run that launched this one. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l root-run -d 'The root of the launch tree. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l usage-root -d 'The root\'s usage ledger, charged for this run. Internal' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l launch-agents -d 'The agents the parent may launch: this run\'s cap. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l launch-workflows -d 'The workflows the parent may launch: this run\'s cap. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l launch-actions -d 'The connector tools the parent was narrowed to. Internal' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l plain -d 'Use the plain line printer instead of the live graph view'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l launch-no-messaging -d 'The parent\'s messaging is off, so this run\'s is too (spec F1d D6). Internal'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from run" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -l limit -d 'Show only the N most recent runs' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -l status -d 'Filter by status: `pending` / `running` / `completed` / `failed` / `awaiting_approval` / `rejected`' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -l issue -d 'Filter by issue ref (full or shorthand). Matches the textual `RunRecord.issue_ref` persisted at run start. Accepts `<platform>:<owner>/<repo>/issues/<N>` (full), `<owner>/<repo>#<N>` (GitHub shorthand), or bare `<N>` (autodetects from cwd\'s git remote)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env, `[ui].color = "never"` in config)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from runs" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -l view -d 'Live view density for the retained snapshot' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env, `[ui].color = \\"never\\"` in config)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -l pager -d 'Force pager. Default: page when stdout is a tty'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -l no-pager -d 'Disable pager'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from show-run" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from approve" -l mode -d 'Override permission mode for the resumed run (`ask` | `bypass` | `readonly`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from approve" -l gate -d 'Target a specific parked approval gate by step id — required once a run has more than one gate parked at once (a concurrent DAG run with several gates in the same batch-park wave). Omit for the legacy/single-gate case: the sole parked gate is approved exactly as before. Approving one gate of several leaves the others parked; the run stays `awaiting_approval` until every gate is resolved' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from approve" -l approver -d 'Override the recorded approver identity. Internal: this is how `cp serve`\'s resume worker carries a web-initiated approve\'s true actor (e.g. `"web"`) across the process boundary — it reads the run\'s `resume_approver` marker and re-derives this flag when spawning `rupu workflow approve`. A direct operator invocation should omit it; the approver then defaults to the OS user running this process, exactly as before this flag existed' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from approve" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from approve" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from approve" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from approve" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from approve" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from reject" -l reason -d 'Optional human-readable reason recorded in the run\'s `error_message`' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from reject" -l gate -d 'Target a specific parked approval gate by step id — same targeting rule as `approve --gate`. Rejecting one gate of several runs THAT gate\'s `on_reject` cleanup chain and leaves the others parked; the run flips to `rejected` only once every gate is resolved' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from reject" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from reject" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from reject" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from reject" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from reject" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from cancel" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from cancel" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from cancel" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from cancel" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from cancel" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from pause" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from pause" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from pause" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from pause" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from pause" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -l mode -d 'Override permission mode for the resumed run (`ask` | `bypass` | `readonly`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -l plain -d 'Use the plain line printer instead of the live graph view'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -l if-unfinished -d 'Resume only a run that has not finished. Internal: `cp serve`\'s resume worker and gate sweep pass it when they spawn this command to serve a request made while the run was unfinished (a web resume of a pause, gate decisions recorded on a waiting run). A run that finished since — completed, failed, rejected, cancelled — is refused rather than retried: retrying a finished run is an operator\'s call, made without this flag'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -l restart-interrupted -d 'Start every interrupted step and `for_each` unit over from its prompt instead of continuing it from its transcript'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from resume" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from archive-run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from archive-run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from archive-run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from archive-run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from archive-run" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from restore-run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from restore-run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from restore-run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from restore-run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from restore-run" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from delete-run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from delete-run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from delete-run" -l force -d 'Confirm the permanent deletion (required). A run that has not finished is refused even with `--force`; cancel it first'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from delete-run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from delete-run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from delete-run" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "list" -d 'List all workflows (global + project)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "show" -d 'Inspect a workflow definition'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "edit" -d 'Open a workflow file in `$VISUAL` / `$EDITOR`. Validates the YAML on save (warn-only)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "create" -d 'Scaffold a new workflow YAML from a template, then open it for editing. Prompts interactively for scope and name when omitted. With `--describe`, a model drafts the definition before you review it'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "run" -d 'Run a workflow'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "runs" -d 'List recent workflow runs from the persistent run-store (`<global>/runs/`). Newest first'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "show-run" -d 'Inspect one persisted run: status, inputs, per-step transcript pointers'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "approve" -d 'Approve a paused run and resume execution from the awaited step. The run must be in `awaiting_approval` status'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "reject" -d 'Reject a paused run. Marks it `rejected`; no further steps dispatch'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "cancel" -d 'Cancel a running workflow run'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "pause" -d 'Cooperatively pause a running workflow run at its next safe boundary, leaving it non-terminal and resumable via `rupu workflow resume`'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "resume" -d 'Resume a failed/cancelled run, re-running only the agent runs that didn\'t succeed. An agent run the interrupted process left mid-flight is picked up where it stopped (or its finished answer reused) rather than started over'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "archive-run" -d 'Archive a terminal run (move it out of the active list; reversible)'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "restore-run" -d 'Restore an archived run back to the active list'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "delete-run" -d 'Permanently delete a run and its transcripts. Requires `--force`'
complete -c rupu -n "__fish_rupu_using_subcommand workflow; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -f -a "run" -d 'Run an agentiflow in the foreground until its envelope stops it'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -f -a "list" -d 'List agentiflow runs, newest first'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -f -a "status" -d 'Show one agentiflow run: goals, budget, rounds and why it stopped'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -f -a "send" -d 'Send a message to a running agentiflow\'s lead, as its operator'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -f -a "stop" -d 'Stop a running agentiflow'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -f -a "attach" -d 'Watch an agentiflow run: its event log and its lead\'s current round'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -f -a "serve" -d 'Supervise agentiflow runs: reap the ones whose coordinator died'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and not __fish_seen_subcommand_from run list status send stop attach serve help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from run" -l run-id -d 'Internal: the run id a detached parent minted for this process, so the id it printed is the run this process records' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from run" -l detach -d 'Run in the background: start the run in its own process group and return once it has started. The background process\'s stderr is kept in `<run dir>/detach.log`; a run that fails before it starts has that error printed here and no run directory left behind'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from run" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from status" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from status" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from status" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from status" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from send" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from send" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from send" -l now -d 'Mark the message urgent and end the lead\'s current round early'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from send" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from send" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from send" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from stop" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from stop" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from stop" -l now -d 'Hard stop: signal the coordinator and its units now'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from stop" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from stop" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from stop" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from attach" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from attach" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from attach" -l no-follow -l once -d 'Print what the run has recorded so far and return, instead of following it until it ends'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from attach" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from attach" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from attach" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from serve" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from serve" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from serve" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from serve" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from serve" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from help" -f -a "run" -d 'Run an agentiflow in the foreground until its envelope stops it'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from help" -f -a "list" -d 'List agentiflow runs, newest first'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show one agentiflow run: goals, budget, rounds and why it stopped'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from help" -f -a "send" -d 'Send a message to a running agentiflow\'s lead, as its operator'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from help" -f -a "stop" -d 'Stop a running agentiflow'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from help" -f -a "attach" -d 'Watch an agentiflow run: its event log and its lead\'s current round'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from help" -f -a "serve" -d 'Supervise agentiflow runs: reap the ones whose coordinator died'
complete -c rupu -n "__fish_rupu_using_subcommand agentiflow; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -f -a "list" -d 'Show what was said in a run\'s message space'
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -f -a "send" -d 'Send a message into a running run\'s message space, as its operator'
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -f -a "participants" -d 'List the participants in a run\'s message space'
complete -c rupu -n "__fish_rupu_using_subcommand message; and not __fish_seen_subcommand_from list send participants help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -l after -d 'Only the messages after this one (`msg_...`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -l kind -d 'Only these kinds, comma-separated: post, direct, broadcast, directive, retract, operator' -r
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -l follow -d 'Keep printing new messages and receipts until the run stops'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -l json -d 'Print JSON: the whole view, or with `--follow` one message per line'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from send" -l to -d 'Who the message is for: a participant, a codename, `role:<agent>`, `step:<id>`, `lead` or `broadcast`' -r
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from send" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from send" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from send" -l urgent -d 'Put the message first; an agentiflow lead ends its round early'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from send" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from send" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from send" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from participants" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from participants" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from participants" -l json -d 'Print the participants as JSON'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from participants" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from participants" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from participants" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from help" -f -a "list" -d 'Show what was said in a run\'s message space'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from help" -f -a "send" -d 'Send a message into a running run\'s message space, as its operator'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from help" -f -a "participants" -d 'List the participants in a run\'s message space'
complete -c rupu -n "__fish_rupu_using_subcommand message; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "list" -d 'List autoflow-enabled workflows'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "show" -d 'Show one autoflow workflow and its resolved metadata'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "run" -d 'Execute one autonomous cycle for one issue target'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "tick" -d 'Reconcile every discovered autoflow once'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "serve" -d 'Run the autoflow reconciler as a long-lived local worker'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "stop" -d 'Stop a running local autoflow serve worker'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "wakes" -d 'Inspect queued and recently processed wakes'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "monitor" -d 'Show a read-only operator view across workers, claims, wakes, and recent activity'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "history" -d 'Show durable autoflow cycle and event history'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "explain" -d 'Explain the current autonomous state for one issue'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "doctor" -d 'Run consistency checks across claims, wakes, and runs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "repair" -d 'Apply safe, bounded remediation to one issue claim'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "requeue" -d 'Enqueue one manual wake for an issue'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "status" -d 'Summarize persisted autoflow claim state'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "claims" -d 'Inspect persisted autoflow claims'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "release" -d 'Force-release one claim'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "create" -d 'Scaffold a new autoflow-enabled workflow YAML, then open it for editing. Same template as `workflow create` plus an `autoflow:` block pre-filled with reasonable defaults'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and not __fish_seen_subcommand_from list show run tick serve stop wakes monitor history explain doctor repair requeue status claims release create help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from list" -l repo -d 'Limit results to one repo target, for example `github:owner/repo`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from show" -l repo -d 'Limit resolution to one tracked repo' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from run" -l repo -d 'Limit resolution to one bound repo' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from run" -l mode -d 'Override permission mode (`bypass` | `readonly`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from run" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from tick" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from tick" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from tick" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from tick" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from tick" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l repo -d 'Limit reconciliation to one tracked repo' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l worker -d 'Optional worker name override, for example `team-mini-01`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l idle-sleep -d 'Idle sleep between reconciliation passes, for example `10s`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l view -d 'Live operator view mode (`focused`, `compact`, or `full`)' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l quiet -d 'Suppress the live interactive serve view'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from serve" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from stop" -l worker -d 'Limit to one worker id or display name' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from stop" -l repo -d 'Limit to one repo filter, for example `github:owner/repo`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from stop" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from stop" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from stop" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from stop" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from stop" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from wakes" -l repo -d 'Limit results to one repo target, for example `github:owner/repo`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from wakes" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from wakes" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from wakes" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from wakes" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from wakes" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l repo -d 'Limit results to one repo target, for example `github:owner/repo`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l worker -d 'Limit results to one worker id or display name' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l interval -d 'Refresh interval for `--watch`, for example `2s`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l view -d 'Human/operator view mode (`focused`, `compact`, or `full`)' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l watch -d 'Refresh the operator view until interrupted'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from monitor" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l repo -d 'Limit results to one repo target, for example `github:owner/repo`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l source -d 'Limit results to one source target, for example `linear:eng-team`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l worker -d 'Limit results to one worker id or display name' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l event -d 'Limit results to one event kind, for example `run_launched`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l limit -d 'Maximum number of history rows to show' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l interval -d 'Refresh interval for `--watch`, for example `2s`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l view -d 'Human/operator view mode (`focused`, `compact`, or `full`)' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l watch -d 'Refresh the operator view until interrupted'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from history" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from explain" -l repo -d 'Limit resolution to one bound repo' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from explain" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from explain" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from explain" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from explain" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from explain" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from doctor" -l repo -d 'Limit results to one repo target, for example `github:owner/repo`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from doctor" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from doctor" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from doctor" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from doctor" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from doctor" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from repair" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from repair" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from repair" -l release -d 'Explicitly release the claim after repair'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from repair" -l requeue -d 'Explicitly enqueue a follow-up wake after repair'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from repair" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from repair" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from repair" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from requeue" -l event -d 'Override the synthetic event id' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from requeue" -l not-before -d 'Delay wake visibility by a relative duration like `10m`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from requeue" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from requeue" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from requeue" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from requeue" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from requeue" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from status" -l repo -d 'Limit results to one repo target, for example `github:owner/repo`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from status" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from status" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from status" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from status" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from claims" -l repo -d 'Limit results to one repo target, for example `github:owner/repo`' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from claims" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from claims" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from claims" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from claims" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from claims" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from release" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from release" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from release" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from release" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from release" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from create" -l scope -d 'Target scope (`global` or `project`). Prompts when omitted' -r -f -a "global\t''
project\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from create" -l editor -d 'Override the editor (e.g. `--editor "code --wait"`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from create" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from create" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from create" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from create" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from create" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "list" -d 'List autoflow-enabled workflows'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "show" -d 'Show one autoflow workflow and its resolved metadata'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "run" -d 'Execute one autonomous cycle for one issue target'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "tick" -d 'Reconcile every discovered autoflow once'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "serve" -d 'Run the autoflow reconciler as a long-lived local worker'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "stop" -d 'Stop a running local autoflow serve worker'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "wakes" -d 'Inspect queued and recently processed wakes'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "monitor" -d 'Show a read-only operator view across workers, claims, wakes, and recent activity'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "history" -d 'Show durable autoflow cycle and event history'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "explain" -d 'Explain the current autonomous state for one issue'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "doctor" -d 'Run consistency checks across claims, wakes, and runs'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "repair" -d 'Apply safe, bounded remediation to one issue claim'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "requeue" -d 'Enqueue one manual wake for an issue'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "status" -d 'Summarize persisted autoflow claim state'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "claims" -d 'Inspect persisted autoflow claims'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "release" -d 'Force-release one claim'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "create" -d 'Scaffold a new autoflow-enabled workflow YAML, then open it for editing. Same template as `workflow create` plus an `autoflow:` block pre-filled with reasonable defaults'
complete -c rupu -n "__fish_rupu_using_subcommand autoflow; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -f -a "list" -d 'List transcripts (project-local + global) sorted newest first'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -f -a "show" -d 'Print a transcript\'s full event stream'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -f -a "archive" -d 'Archive a standalone transcript and its metadata'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -f -a "delete" -d 'Permanently delete a standalone transcript and its metadata'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -f -a "prune" -d 'Delete archived standalone transcripts older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and not __fish_seen_subcommand_from list show archive delete prune help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -l limit -d 'Show only the N most recent transcripts. Pass a large value to list everything — every row beyond the limit costs a full read of its transcript, and a busy workspace accumulates thousands' -r
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -l no-color -d 'Disable terminal colors. Honors `NO_COLOR` and the `[ui].color` config knob too — flag is the explicit override'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -l all -d 'Include both active and archived transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -l archived -d 'Show only archived transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -l view -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env var)'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -l pager -d 'Force pager. Default: page when stdout is a tty'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -l no-pager -d 'Disable pager'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from archive" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from archive" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from archive" -l ignore-liveness -d 'Skip the still-running check; only use when the recorded pid was reused by an unrelated process — deleting a live run\'s transcript loses it'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from archive" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from archive" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from archive" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from delete" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from delete" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from delete" -l force -d 'Confirm the permanent deletion (required)'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from delete" -l ignore-liveness -d 'Skip the still-running check; only use when the recorded pid was reused by an unrelated process — deleting a live run\'s transcript loses it. Independent of `--force`: both are required to delete a transcript that still looks live'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from delete" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from delete" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from delete" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from prune" -l older-than -d 'Retention cutoff, e.g. `30d`, `12h`, or `1w`' -r
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from prune" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from prune" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from prune" -l dry-run -d 'Preview deletions without removing files'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from prune" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from prune" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from prune" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from help" -f -a "list" -d 'List transcripts (project-local + global) sorted newest first'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from help" -f -a "show" -d 'Print a transcript\'s full event stream'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from help" -f -a "archive" -d 'Archive a standalone transcript and its metadata'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from help" -f -a "delete" -d 'Permanently delete a standalone transcript and its metadata'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from help" -f -a "prune" -d 'Delete archived standalone transcripts older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand transcript; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand config; and not __fish_seen_subcommand_from get set help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand config; and not __fish_seen_subcommand_from get set help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand config; and not __fish_seen_subcommand_from get set help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand config; and not __fish_seen_subcommand_from get set help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand config; and not __fish_seen_subcommand_from get set help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand config; and not __fish_seen_subcommand_from get set help" -f -a "get" -d 'Print the value of a key. Dotted keys (`ui.theme`) descend into nested tables'
complete -c rupu -n "__fish_rupu_using_subcommand config; and not __fish_seen_subcommand_from get set help" -f -a "set" -d 'Set a key. Dotted keys (`ui.theme`) descend into nested tables, creating them as needed. The value is parsed as a TOML scalar (string / integer / bool)'
complete -c rupu -n "__fish_rupu_using_subcommand config; and not __fish_seen_subcommand_from get set help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from get" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from get" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from get" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from get" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from get" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from set" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from set" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from set" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from set" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from set" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "get" -d 'Print the value of a key. Dotted keys (`ui.theme`) descend into nested tables'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "set" -d 'Set a key. Dotted keys (`ui.theme`) descend into nested tables, creating them as needed. The value is parsed as a TOML scalar (string / integer / bool)'
complete -c rupu -n "__fish_rupu_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "list" -d 'List customers'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "show" -d 'Metadata, assigned projects, and the customer\'s effective config'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "create" -d 'Create a customer'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "set" -d 'Change metadata. An empty value clears `--notes`, `--contact`, `--color`'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "edit" -d 'Edit the customer\'s config layer in $EDITOR (validated on save)'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "archive" -d 'Hide a customer from pickers; its projects keep running'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "unarchive" -d 'Restore an archived customer to pickers'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "delete" -d 'Delete a customer. Refused while any project is assigned'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "assign" -d 'Assign a project (default: the current directory)'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "unassign" -d 'Remove a project\'s customer (default: the current directory)'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and not __fish_seen_subcommand_from list show create set edit archive unarchive delete assign unassign help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from list" -l archived -d 'Include archived customers'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -l name -d 'Display name' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -l notes -d 'Free-form notes' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -l contact -d 'Contact (a person, email, or channel)' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -l color -d 'Display color, `#rrggbb`' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from create" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -l name -d 'New display name' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -l notes -d 'New notes; an empty value clears them' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -l contact -d 'New contact; an empty value clears it' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -l color -d 'New display color, `#rrggbb`; an empty value clears it' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from set" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from edit" -l editor -d 'Editor command; defaults to `[ui].editor`, then $VISUAL / $EDITOR' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from edit" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from edit" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from edit" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from edit" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from edit" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from archive" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from archive" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from archive" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from archive" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from archive" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unarchive" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unarchive" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unarchive" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unarchive" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unarchive" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from delete" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from delete" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from delete" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from delete" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from delete" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from assign" -l project -d 'A project directory or workspace id (`ws_…`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from assign" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from assign" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from assign" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from assign" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from assign" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unassign" -l project -d 'A project directory or workspace id (`ws_…`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unassign" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unassign" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unassign" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unassign" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from unassign" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "list" -d 'List customers'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "show" -d 'Metadata, assigned projects, and the customer\'s effective config'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "create" -d 'Create a customer'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "set" -d 'Change metadata. An empty value clears `--notes`, `--contact`, `--color`'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "edit" -d 'Edit the customer\'s config layer in $EDITOR (validated on save)'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "archive" -d 'Hide a customer from pickers; its projects keep running'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "unarchive" -d 'Restore an archived customer to pickers'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "delete" -d 'Delete a customer. Refused while any project is assigned'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "assign" -d 'Assign a project (default: the current directory)'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "unassign" -d 'Remove a project\'s customer (default: the current directory)'
complete -c rupu -n "__fish_rupu_using_subcommand customer; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and not __fish_seen_subcommand_from themes theme help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand ui; and not __fish_seen_subcommand_from themes theme help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand ui; and not __fish_seen_subcommand_from themes theme help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and not __fish_seen_subcommand_from themes theme help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and not __fish_seen_subcommand_from themes theme help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and not __fish_seen_subcommand_from themes theme help" -f -a "themes" -d 'List available UI themes'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and not __fish_seen_subcommand_from themes theme help" -f -a "theme" -d 'Manage a specific palette theme'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and not __fish_seen_subcommand_from themes theme help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from themes" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from themes" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from themes" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from themes" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from themes" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -f -a "show" -d 'Show one theme in detail'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -f -a "validate" -d 'Validate a theme file on disk'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -f -a "import" -d 'Import a theme from a local file or URL'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from theme" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from help" -f -a "themes" -d 'List available UI themes'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from help" -f -a "theme" -d 'Manage a specific palette theme'
complete -c rupu -n "__fish_rupu_using_subcommand ui; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l older-than -d 'Retention cutoff override for every selected resource, e.g. `30d`, `12h`, or `1w`' -r
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l stats -d 'Show cleanup inventory instead of deleting archived resources'
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l dry-run -d 'Preview deletions without removing files'
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l sessions -d 'Only clean archived sessions'
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l transcripts -d 'Only clean archived standalone transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand cleanup" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -f -a "login" -d 'Store credentials for a provider'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -f -a "logout" -d 'Remove a stored credential'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -f -a "status" -d 'Show configured providers + backend'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -f -a "backend" -d 'Show where credentials are stored'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and not __fish_seen_subcommand_from login logout status backend help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -l account -d 'Account name — the identity. Use a distinct name per identity (e.g. `anthropic-work`, `anthropic-personal`). A bare vendor name (`anthropic`) is the single-account default' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -l kind -d 'Vendor this account authenticates against (anthropic | openai | gemini | copilot | github | gitlab | linear | jira | local). Required the first time an account name is used; inferred from config or from the account name afterwards' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -l mode -d 'Authentication mode' -r -f -a "api-key\t''
sso\t''"
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -l key -d 'API key (only valid with --mode api-key). If omitted, reads from stdin' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from login" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -l account -d 'Account name (omit with --all to clear everything)' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -l mode -d 'Specific auth mode to remove. If omitted, both api-key and sso for that provider are removed' -r -f -a "api-key\t''
sso\t''"
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -l all -d 'Remove every stored credential across all providers and modes'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -l yes -d 'Skip the confirmation prompt for --all'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from logout" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from status" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from status" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from status" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from status" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l use -d '`file` — the only supported value, and already in effect. Accepted so existing scripts keep working; `keychain` is refused with an explanation. Omit to print where credentials currently live' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l view -d 'Human snapshot density (`focused` | `compact` | `full`)' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l no-color -d 'Disable colored output'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l pager -d 'Force pager. Default: page when stdout is a tty'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l no-pager -d 'Disable pager'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from backend" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "login" -d 'Store credentials for a provider'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "logout" -d 'Remove a stored credential'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show configured providers + backend'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "backend" -d 'Show where credentials are stored'
complete -c rupu -n "__fish_rupu_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand models; and not __fish_seen_subcommand_from list refresh help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand models; and not __fish_seen_subcommand_from list refresh help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand models; and not __fish_seen_subcommand_from list refresh help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand models; and not __fish_seen_subcommand_from list refresh help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand models; and not __fish_seen_subcommand_from list refresh help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand models; and not __fish_seen_subcommand_from list refresh help" -f -a "list" -d 'List available models (custom + cached + baked-in)'
complete -c rupu -n "__fish_rupu_using_subcommand models; and not __fish_seen_subcommand_from list refresh help" -f -a "refresh" -d 'Re-fetch live model lists from each provider'
complete -c rupu -n "__fish_rupu_using_subcommand models; and not __fish_seen_subcommand_from list refresh help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from list" -l provider -d 'Filter output to a single provider' -r
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from refresh" -l provider -d 'Limit refresh to a single provider' -r
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from refresh" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from refresh" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from refresh" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from refresh" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from refresh" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from help" -f -a "list" -d 'List available models (custom + cached + baked-in)'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from help" -f -a "refresh" -d 'Re-fetch live model lists from each provider'
complete -c rupu -n "__fish_rupu_using_subcommand models; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and not __fish_seen_subcommand_from show prune help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and not __fish_seen_subcommand_from show prune help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and not __fish_seen_subcommand_from show prune help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and not __fish_seen_subcommand_from show prune help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and not __fish_seen_subcommand_from show prune help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and not __fish_seen_subcommand_from show prune help" -f -a "show" -d 'Print one run\'s netflow flow records'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and not __fish_seen_subcommand_from show prune help" -f -a "prune" -d 'Delete per-run netflow ledgers older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and not __fish_seen_subcommand_from show prune help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from prune" -l older-than -d 'Retention cutoff, e.g. `30d`, `12h`, or `1w`. Must be positive — `0s` or a negative value is rejected, not treated as "everything". Defaults to `30d` (mirrors `transcript prune`\'s own fallback) when omitted. A ledger is matched by file mtime, but a ledger whose run is still live is never deleted however old it is: a workflow run that is not finished (and whose recorded runner pid, if any, is alive) protects its own, its steps\', its fan-out units\' and its sub-agents\' ledgers, and a standalone `rupu run` whose process is alive protects its own and its sub-agents\'. Such ledgers are listed as `skipped_live`. Anything modified in roughly the last hour is never eligible regardless of what you pass here' -r
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from prune" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from prune" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from prune" -l dry-run -d 'Preview deletions without removing files. Always cheap to run first — the default (no flag) deletes immediately, same as `transcript prune`'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from prune" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from prune" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from prune" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from help" -f -a "show" -d 'Print one run\'s netflow flow records'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from help" -f -a "prune" -d 'Delete per-run netflow ledgers older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand netflow; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -f -a "list" -d 'List repositories accessible via configured SCM platforms'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -f -a "attach" -d 'Attach a local checkout to a repo ref in the local registry'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -f -a "prefer" -d 'Mark one tracked checkout as the preferred path for a repo'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -f -a "tracked" -d 'List locally tracked repo checkouts'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -f -a "forget" -d 'Forget a tracked repo or one tracked path'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and not __fish_seen_subcommand_from list attach prefer tracked forget help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from list" -l platform -d 'Filter to one platform (`github` | `gitlab`). Default: all' -r
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from list" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env, `[ui].color = "never"` in config)'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from attach" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from attach" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from attach" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from attach" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from attach" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from prefer" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from prefer" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from prefer" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from prefer" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from prefer" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from tracked" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from tracked" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from tracked" -l no-color -d 'Disable colored output'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from tracked" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from tracked" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from tracked" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from forget" -l path -d 'Remove only this local path from the tracked repo. When omitted, the entire tracked repo record is deleted' -r
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from forget" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from forget" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from forget" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from forget" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from forget" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "list" -d 'List repositories accessible via configured SCM platforms'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "attach" -d 'Attach a local checkout to a repo ref in the local registry'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "prefer" -d 'Mark one tracked checkout as the preferred path for a repo'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "tracked" -d 'List locally tracked repo checkouts'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "forget" -d 'Forget a tracked repo or one tracked path'
complete -c rupu -n "__fish_rupu_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and not __fish_seen_subcommand_from bind accounts help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand scm; and not __fish_seen_subcommand_from bind accounts help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand scm; and not __fish_seen_subcommand_from bind accounts help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and not __fish_seen_subcommand_from bind accounts help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and not __fish_seen_subcommand_from bind accounts help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and not __fish_seen_subcommand_from bind accounts help" -f -a "bind" -d 'Add an account-selection rule: route repos under an owner glob, or checkouts under a path glob, to a named account'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and not __fish_seen_subcommand_from bind accounts help" -f -a "accounts" -d 'List configured SCM accounts: kind, base_url, and which rules point at them'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and not __fish_seen_subcommand_from bind accounts help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from bind" -l owner -d 'Owner glob this rule matches (e.g. `acme/*` or `acme`). Matched against `RepoRef.owner` — the tier that works for daemons, which know the owner but have no cwd. Mutually exclusive with `--path`; exactly one is required' -r
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from bind" -l path -d 'Filesystem-path glob this rule matches against the caller\'s cwd (e.g. `~/Code/work/*`). Mutually exclusive with `--owner`' -r
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from bind" -l account -d 'The account this rule selects' -r
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from bind" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from bind" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from bind" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from bind" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from bind" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from accounts" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from accounts" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from accounts" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from accounts" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from accounts" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from help" -f -a "bind" -d 'Add an account-selection rule: route repos under an owner glob, or checkouts under a path glob, to a named account'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from help" -f -a "accounts" -d 'List configured SCM accounts: kind, base_url, and which rules point at them'
complete -c rupu -n "__fish_rupu_using_subcommand scm; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "start" -d 'Start a persistent agent session'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "list" -d 'List persistent agent sessions'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "show" -d 'Show session details'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "usage-timeline" -d 'Per-turn token series across every run this session recorded'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "archive" -d 'Archive an inactive session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "restore" -d 'Restore an archived session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "delete" -d 'Permanently delete a session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "prune" -d 'Delete archived sessions older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "send" -d 'Send a follow-up prompt to an existing session'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "attach" -d 'Attach to the current or last run in a session'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "stop" -d 'Stop an active session worker'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "compact" -d 'Compact a session\'s stored conversation (summarize older turns now)'
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "_worker"
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "_run-turn"
complete -c rupu -n "__fish_rupu_using_subcommand session; and not __fish_seen_subcommand_from start list show usage-timeline archive restore delete prune send attach stop compact _worker _run-turn help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l prompt -d 'Initial user message via flag (preferred over the positional `prompt`; lets a caller pass a prompt without it being parsed as a target)' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l mode -d 'Override permission mode (`ask` | `bypass` | `readonly`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l into -d 'For repo targets: clone into this directory instead of `./<repo>/`' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l view -d 'Live renderer mode when auto-attaching' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l engagement-profile -l engagement-profiles -d 'Engagement profile(s) every turn of the session runs under — the asset domain(s) findings are validated against (e.g. `network`, `binary`). Repeatable or comma-separated. Empty = the `code` path' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l skill -d 'A skill every turn of the session is given beside the agent\'s own (`name`, `global:name` or `project:name`). Repeatable' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l preload-skill -d 'A skill whose instructions go into the session\'s system prompt. Repeatable' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l no-stream -d 'Don\'t render tokens as they arrive, for every turn in this session. The request still streams on the wire, so long responses can\'t hit the request timeout'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l detach -d 'Start the first turn without auto-attaching'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from start" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from list" -l all -d 'Include both active and archived sessions'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from list" -l archived -d 'Show only archived sessions'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -l view -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env var)'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -l pager -d 'Force pager. Default: page when stdout is a tty'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -l no-pager -d 'Disable pager'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from usage-timeline" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from usage-timeline" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from usage-timeline" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from usage-timeline" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from usage-timeline" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from archive" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from archive" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from archive" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from archive" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from archive" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from restore" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from restore" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from restore" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from restore" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from restore" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from delete" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from delete" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from delete" -l force -d 'Confirm the permanent deletion (required). A session whose worker is still running is refused even with `--force`; stop it first'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from delete" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from delete" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from delete" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from prune" -l older-than -d 'Retention cutoff, e.g. `30d`, `12h`, or `1w`' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from prune" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from prune" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from prune" -l dry-run -d 'Preview deletions without removing files'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from prune" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from prune" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from prune" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from send" -l skill -d 'A skill to invoke in this turn (`name`, `global:name` or `project:name`): any installed skill, granted or not. Its instructions go ahead of the prompt, and the session may load it from then on. Repeatable' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from send" -l view -d 'Live renderer mode when auto-attaching' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from send" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from send" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from send" -l detach -d 'Start the turn without auto-attaching'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from send" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from send" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from send" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from attach" -l view -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from attach" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from attach" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from attach" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from attach" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from attach" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from stop" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from stop" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from stop" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from stop" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from stop" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from compact" -l window -d 'Context-window size (tokens) to size compaction against. Overrides the session\'s stored `contextWindowTokens`; required for sessions created before that field existed' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from compact" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from compact" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from compact" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from compact" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from compact" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _worker" -l session-id -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _worker" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _worker" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _worker" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _worker" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _worker" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _run-turn" -l session-id -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _run-turn" -l run-id -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _run-turn" -l prompt -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _run-turn" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _run-turn" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _run-turn" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _run-turn" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from _run-turn" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "start" -d 'Start a persistent agent session'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "list" -d 'List persistent agent sessions'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "show" -d 'Show session details'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "usage-timeline" -d 'Per-turn token series across every run this session recorded'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "archive" -d 'Archive an inactive session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "restore" -d 'Restore an archived session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "delete" -d 'Permanently delete a session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "prune" -d 'Delete archived sessions older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "send" -d 'Send a follow-up prompt to an existing session'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "attach" -d 'Attach to the current or last run in a session'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "stop" -d 'Stop an active session worker'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "compact" -d 'Compact a session\'s stored conversation (summarize older turns now)'
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "_worker"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "_run-turn"
complete -c rupu -n "__fish_rupu_using_subcommand session; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -f -a "list" -d 'List issues for a repo. Auto-detects repo from cwd\'s `origin` remote when `--repo` is omitted'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -f -a "show" -d 'Show one issue\'s full body + metadata'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -f -a "run" -d 'Convenience: run a workflow with an issue run-target. Equivalent to `rupu workflow run <name> <issue-ref>` (the run-target is a positional on `workflow run`, not a flag)'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and not __fish_seen_subcommand_from list show run help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l repo -d 'Repo target in the run-target syntax (e.g. `github:Section9Labs/rupu`). When omitted, auto-detected from the cwd\'s git `origin` remote' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l state -d 'Filter by state. `open` (default) | `closed` | `all`' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l label -d 'Filter by label. Repeatable; matched as AND' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l labels -d 'Comma-separated label list (alternative to repeating --label). AND semantics — all listed labels must be present' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l limit -d 'Cap on returned issues. Default: 50' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l account -d 'Which configured SCM account to use, when more than one is configured for this platform (e.g. two GitHub accounts). Skips the owner/path rule engine entirely. Errors on an unknown name' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env var, `[ui].color = "never"` in config)'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -l account -d 'Which configured SCM account to use, when more than one is configured for this platform. Skips the owner/path rule engine' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -l no-color -d 'Disable colored output'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -l pager -d 'Force pager. Default: page when stdout is a tty'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -l no-pager -d 'Disable pager'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from run" -l mode -d 'Override permission mode (`ask` | `bypass` | `readonly`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from run" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from run" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from run" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from run" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from run" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from help" -f -a "list" -d 'List issues for a repo. Auto-detects repo from cwd\'s `origin` remote when `--repo` is omitted'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from help" -f -a "show" -d 'Show one issue\'s full body + metadata'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from help" -f -a "run" -d 'Convenience: run a workflow with an issue run-target. Equivalent to `rupu workflow run <name> <issue-ref>` (the run-target is a positional on `workflow run`, not a flag)'
complete -c rupu -n "__fish_rupu_using_subcommand issues; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand init" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand init" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand init" -l with-samples -d 'Include the curated agent + workflow templates'
complete -c rupu -n "__fish_rupu_using_subcommand init" -l force -d 'Overwrite existing template files (still merges by default)'
complete -c rupu -n "__fish_rupu_using_subcommand init" -l git -d 'Run `git init` afterwards if the target is not already inside a git repo'
complete -c rupu -n "__fish_rupu_using_subcommand init" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand init" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand init" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and not __fish_seen_subcommand_from serve help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and not __fish_seen_subcommand_from serve help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and not __fish_seen_subcommand_from serve help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and not __fish_seen_subcommand_from serve help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and not __fish_seen_subcommand_from serve help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and not __fish_seen_subcommand_from serve help" -f -a "serve" -d 'Run the MCP server for an external MCP-aware client'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and not __fish_seen_subcommand_from serve help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l transport -d 'Transport. v0 ships stdio only; http returns NotWiredInV0' -r -f -a "stdio\t''
http\t''"
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l tools -d 'The tools to serve, in the agent `tools:` grammar: exact names, legacy aliases, `ns.*`, `core.*` or `*` (comma-separated or repeated). Default: the connector and findings tools (`scm.*,issues.*,github.*,gitlab.*,findings.*`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l mode -d 'Permission mode each call is decided under: `bypass` (default — the MCP client\'s own confirmation UX is in front of every call), `readonly` (refuse workspace writes and external actions) or `ask` (no operator to prompt here, so it allows)' -r
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from serve" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "serve" -d 'Run the MCP server for an external MCP-aware client'
complete -c rupu -n "__fish_rupu_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "list" -d 'List coverage targets recorded under .rupu/coverage/'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "templates" -d 'List or show bundled concern templates'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "catalog" -d 'Print the effective catalog snapshot for a target'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "show" -d 'Show the derived ledger view (touched files + assertions + findings)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "audit" -d 'Generate the coverage audit report for a target'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "gap" -d 'Show only the coverage gaps (in-scope files lacking an assertion)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "diff" -d 'Diff two runs against a target (defaults to `previous latest`)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "runs" -d 'List the runs recorded against a target (to find ids to diff)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "rerun" -d 'Replay an agent run by id, appending a new run to the same target'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and not __fish_seen_subcommand_from list templates catalog show audit gap diff runs rerun help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from templates" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from templates" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from templates" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from templates" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from templates" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from templates" -f -a "list" -d 'List bundled template names'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from templates" -f -a "show" -d 'Print a bundled template\'s concerns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from templates" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from catalog" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from catalog" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from catalog" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from catalog" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from catalog" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from audit" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from audit" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from audit" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from audit" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from audit" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from gap" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from gap" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from gap" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from gap" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from gap" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from diff" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from diff" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from diff" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from diff" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from diff" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from runs" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from runs" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from runs" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from runs" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from runs" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from rerun" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from rerun" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from rerun" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from rerun" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from rerun" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "list" -d 'List coverage targets recorded under .rupu/coverage/'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "templates" -d 'List or show bundled concern templates'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "catalog" -d 'Print the effective catalog snapshot for a target'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "show" -d 'Show the derived ledger view (touched files + assertions + findings)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "audit" -d 'Generate the coverage audit report for a target'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "gap" -d 'Show only the coverage gaps (in-scope files lacking an assertion)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "diff" -d 'Diff two runs against a target (defaults to `previous latest`)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "runs" -d 'List the runs recorded against a target (to find ids to diff)'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "rerun" -d 'Replay an agent run by id, appending a new run to the same target'
complete -c rupu -n "__fish_rupu_using_subcommand coverage; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and not __fish_seen_subcommand_from install list help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and not __fish_seen_subcommand_from install list help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and not __fish_seen_subcommand_from install list help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and not __fish_seen_subcommand_from install list help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and not __fish_seen_subcommand_from install list help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and not __fish_seen_subcommand_from install list help" -f -a "install" -d 'Install the stock fleet (agents + workflows) onto disk'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and not __fish_seen_subcommand_from install list help" -f -a "list" -d 'List the agents and workflows the stock fleet ships'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and not __fish_seen_subcommand_from install list help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from install" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from install" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from install" -l force -d 'Overwrite fleet files that already exist (default: keep them)'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from install" -l project -d 'Install into the current project\'s `.rupu/` instead of the global `~/.rupu`'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from install" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from install" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from help" -f -a "install" -d 'Install the stock fleet (agents + workflows) onto disk'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from help" -f -a "list" -d 'List the agents and workflows the stock fleet ships'
complete -c rupu -n "__fish_rupu_using_subcommand fleet; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -f -a "list" -d 'List installed skills in both layers'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -f -a "show" -d 'Show one skill: frontmatter, files, fingerprints and source. Accepts `global:<name>` / `project:<name>`'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -f -a "validate" -d 'Check skills against the Agent Skills format; exit 1 on any failure'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -f -a "install" -d 'Install skills from a directory, `owner/repo`, a GitHub tree URL, or an https git URL (`#path` narrows to a folder in the repository)'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -f -a "update" -d 'Re-fetch installed skills from the source they were installed from'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and not __fish_seen_subcommand_from list show validate install update help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from list" -l project -d 'Only the project layer'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from show" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from show" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from show" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from show" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from validate" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from validate" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from validate" -l all
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from validate" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from validate" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from validate" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l ref -d 'Branch, tag or commit to install from' -r
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l skill -d 'Install this skill from a source that holds several (repeatable)' -r
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l all -d 'Install every valid skill in the source'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l list -d 'List the skills in the source; install nothing'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l project -d 'Install into the current project\'s `.rupu/skills` instead of `~/.rupu/skills`'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l force -d 'Replace installed skills of the same name'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from update" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from update" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from update" -l all -d 'Every installed skill with a source record'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from update" -l project -d 'The project layer instead of the global one'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from update" -l force -d 'Replace skills whose installed copy was edited'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from update" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from update" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from update" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from help" -f -a "list" -d 'List installed skills in both layers'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from help" -f -a "show" -d 'Show one skill: frontmatter, files, fingerprints and source. Accepts `global:<name>` / `project:<name>`'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from help" -f -a "validate" -d 'Check skills against the Agent Skills format; exit 1 on any failure'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from help" -f -a "install" -d 'Install skills from a directory, `owner/repo`, a GitHub tree URL, or an https git URL (`#path` narrows to a folder in the repository)'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from help" -f -a "update" -d 'Re-fetch installed skills from the source they were installed from'
complete -c rupu -n "__fish_rupu_using_subcommand skill; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -f -a "schema" -d 'Print the finding report JSON Schema embedded in this build'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -f -a "export" -d 'Export findings as a report: one finding, or a project report'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -f -a "import" -d 'Attach reports written before the full profile to their findings'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -f -a "list" -d 'List findings matching a query, e.g. `severity>=high -tag:noise`'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -f -a "tag" -d 'Add or remove tags on findings'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -f -a "tags" -d 'List the tags in use, with how many findings carry each (optionally only on the findings a query selects)'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and not __fish_seen_subcommand_from schema export import list tag tags help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from schema" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from schema" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from schema" -l advertised -d 'Print the simplified copy used in tool definitions instead'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from schema" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from schema" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from schema" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l id -d 'Export this finding (repeatable)' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l project -d 'Only this project: a workspace id, or the path of its checkout' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l run -d 'Only the findings a run (and its sub-runs) declared' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l severity -d 'Only this severity and worse' -r -f -a "critical\t''
high\t''
medium\t''
low\t''
info\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l owner -d 'Only findings whose report names this owner' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l cwe -d 'Only findings for this CWE (e.g. CWE-79), compared by number: CWE-79 never selects CWE-798' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l title -d 'Title of the project report (default: "Findings report")' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l to -d 'Document format' -r -f -a "md\t''
html\t''
pdf\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -s o -l output -d 'Where to write the report. An existing directory receives the generated file name' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l include-summaries -d 'Keep findings recorded without a full report (left out by default)'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l split -d 'Write a zip of one file per finding plus an index'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from export" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from import" -l id -d 'The finding a single report belongs to, for a report with no `Finding ID:` line. Only with one file; refused when the report\'s own `Finding ID:` line names a different finding' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from import" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from import" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from import" -l dry-run -d 'Parse and validate every report, check that the artifacts it lists exist and that it is within the size limits once they are recorded; write nothing (no ledger change, backup or lock file). No artifact is copied (only its first 8 KiB is read), so trouble found only while copying one shows up only on a real import'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from import" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from import" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from import" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from list" -l limit -d 'Show at most N findings; how many were left out goes to stderr' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from list" -l ids-only -d 'Print only the finding ids, one per line'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tag" -l add -d 'Tag to add (repeatable)' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tag" -l remove -d 'Tag to remove (repeatable)' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tag" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tag" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tag" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tag" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tag" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tags" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tags" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tags" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tags" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from tags" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from help" -f -a "schema" -d 'Print the finding report JSON Schema embedded in this build'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from help" -f -a "export" -d 'Export findings as a report: one finding, or a project report'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from help" -f -a "import" -d 'Attach reports written before the full profile to their findings'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from help" -f -a "list" -d 'List findings matching a query, e.g. `severity>=high -tag:noise`'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from help" -f -a "tag" -d 'Add or remove tags on findings'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from help" -f -a "tags" -d 'List the tags in use, with how many findings carry each (optionally only on the findings a query selects)'
complete -c rupu -n "__fish_rupu_using_subcommand findings; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -f -a "list" -d 'List every cron-triggered workflow + its schedule + next-fire time. Read-only; doesn\'t update state'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -f -a "tick" -d 'Walk all workflows, fire any whose schedule matches between the persisted `last_fired` and now. Designed to run from system cron at 1-minute granularity'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -f -a "events" -d 'Read-only inspection of event-triggered workflows'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and not __fish_seen_subcommand_from list tick events help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from list" -l no-color -d 'Disable colored output (also honored: `NO_COLOR` env, `[ui].color = "never"` in config)'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from tick" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from tick" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from tick" -l dry-run -d 'Don\'t actually run workflows or update state; just print what would fire. Useful for verifying a `crontab` line'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from tick" -l skip-events -d 'Run only the cron-scheduled tier; skip event polling. Useful for crontab lines that want predictable cost'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from tick" -l only-events -d 'Run only the event-polling tier; skip cron-scheduled fires. Useful for splitting tick frequencies (cron at 1 min, events at 5 min)'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from tick" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from tick" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from tick" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from events" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from events" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from events" -l no-color -d 'Disable colored output'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from events" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from events" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from events" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from help" -f -a "list" -d 'List every cron-triggered workflow + its schedule + next-fire time. Read-only; doesn\'t update state'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from help" -f -a "tick" -d 'Walk all workflows, fire any whose schedule matches between the persisted `last_fired` and now. Designed to run from system cron at 1-minute granularity'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from help" -f -a "events" -d 'Read-only inspection of event-triggered workflows'
complete -c rupu -n "__fish_rupu_using_subcommand cron; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and not __fish_seen_subcommand_from serve help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and not __fish_seen_subcommand_from serve help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and not __fish_seen_subcommand_from serve help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and not __fish_seen_subcommand_from serve help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and not __fish_seen_subcommand_from serve help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and not __fish_seen_subcommand_from serve help" -f -a "serve" -d 'Run the webhook HTTP receiver in the foreground'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and not __fish_seen_subcommand_from serve help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and __fish_seen_subcommand_from serve" -l addr -d 'Address to bind. Defaults to 127.0.0.1:8080. Use 0.0.0.0 to expose externally (only do this behind a reverse proxy that terminates TLS — rupu does not)' -r
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and __fish_seen_subcommand_from serve" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and __fish_seen_subcommand_from serve" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and __fish_seen_subcommand_from serve" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and __fish_seen_subcommand_from serve" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and __fish_seen_subcommand_from serve" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and __fish_seen_subcommand_from help" -f -a "serve" -d 'Run the webhook HTTP receiver in the foreground'
complete -c rupu -n "__fish_rupu_using_subcommand webhook; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and not __fish_seen_subcommand_from serve help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand cp; and not __fish_seen_subcommand_from serve help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand cp; and not __fish_seen_subcommand_from serve help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and not __fish_seen_subcommand_from serve help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and not __fish_seen_subcommand_from serve help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and not __fish_seen_subcommand_from serve help" -f -a "serve" -d 'Start the control-plane HTTP server'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and not __fish_seen_subcommand_from serve help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from serve" -l bind -d 'Address to bind. Defaults to 127.0.0.1:7878' -r
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from serve" -l token -d 'Optional access token. If set, every `/api/*` call needs it, as `Authorization: Bearer <token>` or the browser\'s token cookie. The printed (and auto-opened) URL carries `?token=<token>`; opening it signs that browser in (cookie set, token dropped from the URL). `/healthz` and the page shell stay open; the UI shows no data until the browser is signed in' -r
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from serve" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from serve" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from serve" -l no-open -d 'Do not open the served URL in a browser on startup. By default the URL is opened when running interactively (a terminal); the URL is always printed regardless'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from serve" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from serve" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from serve" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from help" -f -a "serve" -d 'Start the control-plane HTTP server'
complete -c rupu -n "__fish_rupu_using_subcommand cp; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l since -d 'Only count runs whose `started_at` is at or after this timestamp. RFC-3339 / ISO-8601 (`2026-05-01T00:00:00Z`) or relative (`7d`, `24h`, `30m`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l until -d 'Only count runs whose `started_at` is at or before this timestamp' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l repo -d 'Filter to one repo ref, for example `github:Section9Labs/rupu`' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l issue -d 'Filter to one issue ref, for example `github:Section9Labs/rupu/issues/42`' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l workflow -d 'Filter to one workflow name' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l agent -d 'Filter to one agent name' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l provider -d 'Filter to one provider id' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l model -d 'Filter to one model id' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l worker -d 'Filter to one worker id' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l backend -d 'Filter to one backend id' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l trigger -d 'Filter to one trigger source (`run_cli`, `workflow_cli`, `autoflow`, ...)' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l group-by -d 'Group the main report by one dimension' -r -f -a "composite\t''
provider\t''
model\t''
agent\t''
workflow\t''
repo\t''
day\t''"
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -f -a "runs" -d 'Show per-run usage rows'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -f -a "backfill" -d 'Backfill metadata sidecars for older standalone transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and not __fish_seen_subcommand_from runs backfill help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l since -d 'Only count runs whose `started_at` is at or after this timestamp. RFC-3339 / ISO-8601 (`2026-05-01T00:00:00Z`) or relative (`7d`, `24h`, `30m`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l until -d 'Only count runs whose `started_at` is at or before this timestamp' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l repo -d 'Filter to one repo ref, for example `github:Section9Labs/rupu`' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l issue -d 'Filter to one issue ref, for example `github:Section9Labs/rupu/issues/42`' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l workflow -d 'Filter to one workflow name' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l agent -d 'Filter to one agent name' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l provider -d 'Filter to one provider id' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l model -d 'Filter to one model id' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l worker -d 'Filter to one worker id' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l backend -d 'Filter to one backend id' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l trigger -d 'Filter to one trigger source (`run_cli`, `workflow_cli`, `autoflow`, ...)' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l status -d 'Filter to one run status' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l top-cost -d 'Show only the N most expensive runs' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l failed -d 'Only show failed runs'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from runs" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from backfill" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from backfill" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from backfill" -l force -d 'Rewrite existing standalone sidecars instead of skipping them'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from backfill" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from backfill" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from backfill" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from help" -f -a "runs" -d 'Show per-run usage rows'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from help" -f -a "backfill" -d 'Backfill metadata sidecars for older standalone transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand usage; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand watch" -l pace -d 'Replay pace in events per second (only with --replay)' -r
complete -c rupu -n "__fish_rupu_using_subcommand watch" -l view -d 'Live view density for retained watch screens' -r -f -a "focused\t''
compact\t''
full\t''"
complete -c rupu -n "__fish_rupu_using_subcommand watch" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand watch" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand watch" -l replay -d 'Replay a finished run instead of tailing live'
complete -c rupu -n "__fish_rupu_using_subcommand watch" -l follow -d 'Follow a live run (tail mode). Re-scans the transcript dir every 250ms until the run reaches a terminal state'
complete -c rupu -n "__fish_rupu_using_subcommand watch" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand watch" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand watch" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and not __fish_seen_subcommand_from print install help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand completions; and not __fish_seen_subcommand_from print install help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand completions; and not __fish_seen_subcommand_from print install help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and not __fish_seen_subcommand_from print install help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and not __fish_seen_subcommand_from print install help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and not __fish_seen_subcommand_from print install help" -f -a "print" -d 'Print a completion script for the given shell to stdout'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and not __fish_seen_subcommand_from print install help" -f -a "install" -d 'Write the completion script to the canonical location for the given shell. If `--shell` is omitted, auto-detect from `$SHELL` (best-effort)'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and not __fish_seen_subcommand_from print install help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from print" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from print" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from print" -l static -d 'Emit a static, self-contained script (no runtime callbacks). Drops dynamic agent / workflow name completion in exchange for offline-installable output. Default: dynamic bootstrap'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from print" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from print" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from print" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from install" -l shell -d 'Target shell. Auto-detected from `$SHELL` when omitted' -r -f -a "bash\t''
elvish\t''
fish\t''
powershell\t''
zsh\t''"
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from install" -l path -d 'Install path override. Defaults to the conventional location for the target shell (printed at the end of the run)' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from install" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from install" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from install" -l static -d 'Install the static script (see `print --static`). Default: dynamic bootstrap'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from install" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from install" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from help" -f -a "print" -d 'Print a completion script for the given shell to stdout'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from help" -f -a "install" -d 'Write the completion script to the canonical location for the given shell. If `--shell` is omitted, auto-detect from `$SHELL` (best-effort)'
complete -c rupu -n "__fish_rupu_using_subcommand completions; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -f -a "add" -d 'Register a remote rupu-cp host'
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -f -a "list" -d 'List configured hosts (local is always shown first)'
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -f -a "remove" -d 'Remove a host by id'
complete -c rupu -n "__fish_rupu_using_subcommand host; and not __fish_seen_subcommand_from add list remove help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l url -d 'Base URL of the remote rupu-cp instance (e.g. https://rupu.example.com). Mutually exclusive with `--ssh` and `--bucket`' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l ssh -d 'SSH destination: `user@host` or an `~/.ssh/config` alias. Selects the Ssh transport. Mutually exclusive with `--url` and `--bucket`' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l port -d 'SSH port override (default: 22). Only relevant with `--ssh`' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l identity -d 'Path to an SSH identity file. Only relevant with `--ssh`' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l bucket -d 'Object-store URL for the bucket transport (`s3://…` / `gs://…` / `file://…`). Selects the Bucket transport. Mutually exclusive with `--url` and `--ssh`. Credentials come from the environment / cloud credential chain and are never stored' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l prefix -d 'Object-store key prefix (optional). Only relevant with `--bucket`' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l token -d 'API token. Mutually exclusive with `--token-stdin`. Only relevant with `--url`' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l token-stdin -d 'Read the API token from stdin (one line). Mutually exclusive with `--token`'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from remove" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from remove" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from remove" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from remove" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from remove" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from help" -f -a "add" -d 'Register a remote rupu-cp host'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from help" -f -a "list" -d 'List configured hosts (local is always shown first)'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from help" -f -a "remove" -d 'Remove a host by id'
complete -c rupu -n "__fish_rupu_using_subcommand host; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -l cp-url -d 'WebSocket URL of the control-plane node endpoint (e.g. `ws://cp.example.com:7878/api/node/connect`; the `/api/node/connect` path is appended automatically when omitted). `wss://` requires a TLS-terminating proxy and a TLS-enabled build. Required in agent mode (when no subcommand is given)' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -l token -d 'Authentication token.  Mutually exclusive with `--token-stdin`' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -l node-id -d 'Override the node identity string.  Default: a persistent `node_<ULID>` written to `~/.rupu/node_id` on first run' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -l token-stdin -d 'Read the authentication token from stdin (one line). Preferred over `--token` so the secret does not land in shell history.  Mutually exclusive with `--token`'
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -f -a "enroll" -d 'Enroll a new tunnel node in the local host store and print the `rupu node --cp-url ... --token ...` command to run on the box.  The token is shown ONCE and never persisted on disk'
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -f -a "pull" -d 'Poll a bucket dead-drop, atomically claim jobs, run them locally, write results back, and apply queued control messages'
complete -c rupu -n "__fish_rupu_using_subcommand node; and not __fish_seen_subcommand_from enroll pull help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from enroll" -l cp-url -d 'CP URL to include in the printed command (e.g. `ws://cp.example.com:7878`; the `/api/node/connect` path is appended automatically when omitted).  Default: this machine\'s detected routable IP on port 7878' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from enroll" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from enroll" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from enroll" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from enroll" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from enroll" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l bucket -d 'Bucket URL (e.g. `s3://my-bucket`, `gs://my-bucket`). Credentials are resolved via the environment credential chain' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l prefix -d 'Optional key prefix within the bucket (e.g. `rupu/host-1`)' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l host-id -d 'Override the worker identity.  Default: the stable `node_<ULID>` persisted at `~/.rupu/node_id` (same as the tunnel node agent)' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l interval -d 'Poll interval between ticks in seconds (loop mode only)' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l once -d 'Claim all currently-available jobs, drain them to terminal (bounded), then exit.  In loop mode (the default) the agent runs forever'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from pull" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from help" -f -a "enroll" -d 'Enroll a new tunnel node in the local host store and print the `rupu node --cp-url ... --token ...` command to run on the box.  The token is shown ONCE and never persisted on disk'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from help" -f -a "pull" -d 'Poll a bucket dead-drop, atomically claim jobs, run them locally, write results back, and apply queued control messages'
complete -c rupu -n "__fish_rupu_using_subcommand node; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand update" -l channel -d 'Override the configured channel for this run' -r
complete -c rupu -n "__fish_rupu_using_subcommand update" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand update" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand update" -l check -d 'Only report whether an update is available; install nothing'
complete -c rupu -n "__fish_rupu_using_subcommand update" -l force -d 'Reinstall even if already up to date (or downgrade to the channel\'s latest if this build is ahead of it)'
complete -c rupu -n "__fish_rupu_using_subcommand update" -s y -l yes -d 'Deprecated no-op: `rupu update` no longer prompts, so there is nothing to skip. Still accepted so existing scripts and aliases that pass `-y` keep working'
complete -c rupu -n "__fish_rupu_using_subcommand update" -l rollback -d 'Restore the previously-installed binary from the last backup'
complete -c rupu -n "__fish_rupu_using_subcommand update" -l print-platform -d 'Print this build\'s release-asset platform name (e.g. `linux-x64`) and exit. The release pipeline uses this to name assets from the binary itself, so the publisher and `rupu update` cannot drift'
complete -c rupu -n "__fish_rupu_using_subcommand update" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand update" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand update" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand man" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand man" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand man" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand man" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand man" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -l from -d 'Path to the staged, already-downloaded binary' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -l to -d 'Path to the live binary to replace' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -l sha256 -d 'Expected sha256 of the staged binary (re-verified here, not trusted)' -r
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -l backup -d 'Path to back up the current `--to` binary to before swapping. Computed by the (unprivileged) caller in the USER\'s `$HOME` — under `sudo` this process\'s own `$HOME` may resolve to root\'s home, which `rupu update --rollback` (run as the user) could never find' -r -F
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __apply-update" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -f -a "stage" -d 'Stage a packed workspace read from stdin; print the working dir'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -f -a "collect" -d 'Collect the change-delta from a staged working dir; write it to stdout'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -f -a "discard" -d 'Best-effort discard of a staged working dir\'s scratch (no stdout)'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and not __fish_seen_subcommand_from stage collect discard help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from stage" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from stage" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from stage" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from stage" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from stage" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from collect" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from collect" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from collect" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from collect" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from collect" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from discard" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from discard" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from discard" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from discard" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from discard" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from help" -f -a "stage" -d 'Stage a packed workspace read from stdin; print the working dir'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from help" -f -a "collect" -d 'Collect the change-delta from a staged working dir; write it to stdout'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from help" -f -a "discard" -d 'Best-effort discard of a staged working dir\'s scratch (no stdout)'
complete -c rupu -n "__fish_rupu_using_subcommand __workspace; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and not __fish_seen_subcommand_from missing receive help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and not __fish_seen_subcommand_from missing receive help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and not __fish_seen_subcommand_from missing receive help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and not __fish_seen_subcommand_from missing receive help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and not __fish_seen_subcommand_from missing receive help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and not __fish_seen_subcommand_from missing receive help" -f -a "missing" -d 'Print the `hash:layer:name` refs (arguments) this host hasn\'t cached'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and not __fish_seen_subcommand_from missing receive help" -f -a "receive" -d 'Store the skills framed on stdin (`encode_stream`); print `ok <hash>` per skill'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and not __fish_seen_subcommand_from missing receive help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from missing" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from missing" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from missing" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from missing" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from missing" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from receive" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from receive" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from receive" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from receive" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from receive" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from help" -f -a "missing" -d 'Print the `hash:layer:name` refs (arguments) this host hasn\'t cached'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from help" -f -a "receive" -d 'Store the skills framed on stdin (`encode_stream`); print `ok <hash>` per skill'
complete -c rupu -n "__fish_rupu_using_subcommand __skills; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand __features" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __features" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __features" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __features" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __features" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and not __fish_seen_subcommand_from list send help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __message; and not __fish_seen_subcommand_from list send help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and not __fish_seen_subcommand_from list send help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and not __fish_seen_subcommand_from list send help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and not __fish_seen_subcommand_from list send help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and not __fish_seen_subcommand_from list send help" -f -a "list"
complete -c rupu -n "__fish_rupu_using_subcommand __message; and not __fish_seen_subcommand_from list send help" -f -a "send"
complete -c rupu -n "__fish_rupu_using_subcommand __message; and not __fish_seen_subcommand_from list send help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from list" -l after -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from list" -l limit -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from list" -l kind -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from list" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from list" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from list" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from list" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -l body -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -l to -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -l viewer -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -l urgent
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from send" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from help" -f -a "list"
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from help" -f -a "send"
complete -c rupu -n "__fish_rupu_using_subcommand __message; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and not __fish_seen_subcommand_from artifact help" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and not __fish_seen_subcommand_from artifact help" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and not __fish_seen_subcommand_from artifact help" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and not __fish_seen_subcommand_from artifact help" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and not __fish_seen_subcommand_from artifact help" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and not __fish_seen_subcommand_from artifact help" -f -a "artifact" -d 'Write the stored blob `<sha256>` to stdout; nonzero exit if absent'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and not __fish_seen_subcommand_from artifact help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and __fish_seen_subcommand_from artifact" -l format -d 'Structured output format for commands that support tabular/report views' -r -f -a "table\t''
pretty\t''
json\t''
jsonl\t''
csv\t''"
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and __fish_seen_subcommand_from artifact" -l max-open-files -d 'Raise this process\'s open-file limit (RLIMIT_NOFILE) to N and cap automatic growth there. Overrides `RUPU_MAX_OPEN_FILES` and `[runtime].max_open_files`. Wide fan-outs hold several descriptors per concurrent agent' -r
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and __fish_seen_subcommand_from artifact" -l absolute -d 'Show absolute ISO timestamps in tables instead of relative ages. Useful when correlating a run against external logs'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and __fish_seen_subcommand_from artifact" -l all-columns -d 'Keep every table column, including ones that are empty for every row shown. Columns are otherwise suppressed based on the rows actually displayed, so a filtered listing may show fewer columns'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and __fish_seen_subcommand_from artifact" -s h -l help -d 'Print help'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and __fish_seen_subcommand_from help" -f -a "artifact" -d 'Write the stored blob `<sha256>` to stdout; nonzero exit if absent'
complete -c rupu -n "__fish_rupu_using_subcommand __findings; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "run" -d 'One-shot agent run, or pause/resume a run by id'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "agent" -d 'Manage agents'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "workflow" -d 'Manage workflows'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "agentiflow" -d 'Run goal-directed agent fleets (agentiflows)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "message" -d 'Talk to a run as its operator: its message space\'s messages, participants, and sending into it'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "autoflow" -d 'Run autonomous workflows against persistent issue state'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "transcript" -d 'Browse transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "config" -d 'Get / set configuration values'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "customer" -d 'Customers: group projects under a customer with its own config layer'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "ui" -d 'Manage UI themes and palette imports'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "cleanup" -d 'Prune archived local sessions and transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "auth" -d 'Manage provider credentials'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "models" -d 'List or refresh available models'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "netflow" -d 'Manage per-run netflow ledgers (retention / pruning)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "repos" -d 'SCM repository operations'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "scm" -d 'Multi-account SCM routing: rules and the account roster'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "session" -d 'Persistent agent sessions'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "issues" -d 'Issue-tracker operations (list / show / run a workflow)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "init" -d 'Bootstrap a new rupu project (`.rupu/agents`, `.rupu/workflows`, `.rupu/netflow`, config)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "mcp" -d 'MCP server operations'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "coverage" -d 'Inspect agentic coverage ledgers and concern catalogs'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "fleet" -d 'Install the stock security-assessment fleet (the generic agents + workflows the built-in engagement profiles name) into `~/.rupu`'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "skill" -d 'Agent Skills: install, update, list, show and validate SKILL.md skills'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "findings" -d 'Finding reports: the embedded report schema, and report exports'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "cron" -d 'Schedule-driven workflow firing (designed for system cron)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "webhook" -d 'Webhook receiver for event-triggered workflows (GitHub / GitLab)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "cp" -d 'Control-plane HTTP server for the rupu web UI'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "usage" -d 'Aggregate token spend across persisted transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "watch" -d 'Re-attach to an existing run'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "completions" -d 'Generate or install shell-completion scripts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "host" -d 'Manage named rupu-cp hosts (add / list / remove)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "node" -d 'Dial-home tunnel agent + node enrollment'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "update" -d 'Download and install the latest release for the configured channel'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "man" -d 'Render the man page to stdout'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "__apply-update" -d 'Internal: privileged install step invoked by `rupu update` via `sudo` when the install directory isn\'t user-writable'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "__workspace" -d 'Internal: remote workspace stage/collect helper (SSH workspace sync)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "__skills" -d 'Internal: cache skills shipped to this host (placed-unit skills)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "__features" -d 'Internal: print this build\'s host features (SSH capability probe)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "__message" -d 'Internal: read or write a run\'s message space as its operator (SSH transport); the protocol is `cmd::message::HelperAction`\'s'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "__findings" -d 'Internal: stream a finding artifact from this host\'s store (SSH artifact pull)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and not __fish_seen_subcommand_from run agent workflow agentiflow message autoflow transcript config customer ui cleanup auth models netflow repos scm session issues init mcp coverage fleet skill findings cron webhook cp usage watch completions host node update man __apply-update __workspace __skills __features __message __findings help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agent" -f -a "list" -d 'List all available agents (global + project)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agent" -f -a "show" -d 'Print an agent\'s frontmatter and body'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agent" -f -a "edit" -d 'Open an agent file in `$VISUAL` / `$EDITOR`. Validates the frontmatter on save (warn-only)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agent" -f -a "validate" -d 'Check agent files: each must parse and its `tools:` must name known tools (an unknown name is a load error). Checks every file in the global and project agent dirs with `--all`, shadowed ones included. Exits nonzero when any check fails'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agent" -f -a "create" -d 'Scaffold a new agent file, then open it for editing. Prompts interactively for scope and name when omitted. With `--describe`, a model drafts the definition before you review it'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "list" -d 'List all workflows (global + project)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "show" -d 'Inspect a workflow definition'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "edit" -d 'Open a workflow file in `$VISUAL` / `$EDITOR`. Validates the YAML on save (warn-only)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "create" -d 'Scaffold a new workflow YAML from a template, then open it for editing. Prompts interactively for scope and name when omitted. With `--describe`, a model drafts the definition before you review it'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "run" -d 'Run a workflow'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "runs" -d 'List recent workflow runs from the persistent run-store (`<global>/runs/`). Newest first'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "show-run" -d 'Inspect one persisted run: status, inputs, per-step transcript pointers'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "approve" -d 'Approve a paused run and resume execution from the awaited step. The run must be in `awaiting_approval` status'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "reject" -d 'Reject a paused run. Marks it `rejected`; no further steps dispatch'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "cancel" -d 'Cancel a running workflow run'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "pause" -d 'Cooperatively pause a running workflow run at its next safe boundary, leaving it non-terminal and resumable via `rupu workflow resume`'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "resume" -d 'Resume a failed/cancelled run, re-running only the agent runs that didn\'t succeed. An agent run the interrupted process left mid-flight is picked up where it stopped (or its finished answer reused) rather than started over'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "archive-run" -d 'Archive a terminal run (move it out of the active list; reversible)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "restore-run" -d 'Restore an archived run back to the active list'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from workflow" -f -a "delete-run" -d 'Permanently delete a run and its transcripts. Requires `--force`'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agentiflow" -f -a "run" -d 'Run an agentiflow in the foreground until its envelope stops it'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agentiflow" -f -a "list" -d 'List agentiflow runs, newest first'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agentiflow" -f -a "status" -d 'Show one agentiflow run: goals, budget, rounds and why it stopped'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agentiflow" -f -a "send" -d 'Send a message to a running agentiflow\'s lead, as its operator'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agentiflow" -f -a "stop" -d 'Stop a running agentiflow'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agentiflow" -f -a "attach" -d 'Watch an agentiflow run: its event log and its lead\'s current round'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from agentiflow" -f -a "serve" -d 'Supervise agentiflow runs: reap the ones whose coordinator died'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from message" -f -a "list" -d 'Show what was said in a run\'s message space'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from message" -f -a "send" -d 'Send a message into a running run\'s message space, as its operator'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from message" -f -a "participants" -d 'List the participants in a run\'s message space'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "list" -d 'List autoflow-enabled workflows'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "show" -d 'Show one autoflow workflow and its resolved metadata'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "run" -d 'Execute one autonomous cycle for one issue target'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "tick" -d 'Reconcile every discovered autoflow once'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "serve" -d 'Run the autoflow reconciler as a long-lived local worker'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "stop" -d 'Stop a running local autoflow serve worker'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "wakes" -d 'Inspect queued and recently processed wakes'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "monitor" -d 'Show a read-only operator view across workers, claims, wakes, and recent activity'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "history" -d 'Show durable autoflow cycle and event history'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "explain" -d 'Explain the current autonomous state for one issue'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "doctor" -d 'Run consistency checks across claims, wakes, and runs'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "repair" -d 'Apply safe, bounded remediation to one issue claim'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "requeue" -d 'Enqueue one manual wake for an issue'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "status" -d 'Summarize persisted autoflow claim state'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "claims" -d 'Inspect persisted autoflow claims'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "release" -d 'Force-release one claim'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from autoflow" -f -a "create" -d 'Scaffold a new autoflow-enabled workflow YAML, then open it for editing. Same template as `workflow create` plus an `autoflow:` block pre-filled with reasonable defaults'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from transcript" -f -a "list" -d 'List transcripts (project-local + global) sorted newest first'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from transcript" -f -a "show" -d 'Print a transcript\'s full event stream'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from transcript" -f -a "archive" -d 'Archive a standalone transcript and its metadata'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from transcript" -f -a "delete" -d 'Permanently delete a standalone transcript and its metadata'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from transcript" -f -a "prune" -d 'Delete archived standalone transcripts older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "get" -d 'Print the value of a key. Dotted keys (`ui.theme`) descend into nested tables'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "set" -d 'Set a key. Dotted keys (`ui.theme`) descend into nested tables, creating them as needed. The value is parsed as a TOML scalar (string / integer / bool)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "list" -d 'List customers'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "show" -d 'Metadata, assigned projects, and the customer\'s effective config'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "create" -d 'Create a customer'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "set" -d 'Change metadata. An empty value clears `--notes`, `--contact`, `--color`'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "edit" -d 'Edit the customer\'s config layer in $EDITOR (validated on save)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "archive" -d 'Hide a customer from pickers; its projects keep running'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "unarchive" -d 'Restore an archived customer to pickers'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "delete" -d 'Delete a customer. Refused while any project is assigned'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "assign" -d 'Assign a project (default: the current directory)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from customer" -f -a "unassign" -d 'Remove a project\'s customer (default: the current directory)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from ui" -f -a "themes" -d 'List available UI themes'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from ui" -f -a "theme" -d 'Manage a specific palette theme'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "login" -d 'Store credentials for a provider'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "logout" -d 'Remove a stored credential'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "status" -d 'Show configured providers + backend'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "backend" -d 'Show where credentials are stored'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from models" -f -a "list" -d 'List available models (custom + cached + baked-in)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from models" -f -a "refresh" -d 'Re-fetch live model lists from each provider'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from netflow" -f -a "show" -d 'Print one run\'s netflow flow records'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from netflow" -f -a "prune" -d 'Delete per-run netflow ledgers older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "list" -d 'List repositories accessible via configured SCM platforms'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "attach" -d 'Attach a local checkout to a repo ref in the local registry'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "prefer" -d 'Mark one tracked checkout as the preferred path for a repo'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "tracked" -d 'List locally tracked repo checkouts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "forget" -d 'Forget a tracked repo or one tracked path'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from scm" -f -a "bind" -d 'Add an account-selection rule: route repos under an owner glob, or checkouts under a path glob, to a named account'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from scm" -f -a "accounts" -d 'List configured SCM accounts: kind, base_url, and which rules point at them'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "start" -d 'Start a persistent agent session'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "list" -d 'List persistent agent sessions'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "show" -d 'Show session details'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "usage-timeline" -d 'Per-turn token series across every run this session recorded'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "archive" -d 'Archive an inactive session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "restore" -d 'Restore an archived session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "delete" -d 'Permanently delete a session and its owned transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "prune" -d 'Delete archived sessions older than a cutoff'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "send" -d 'Send a follow-up prompt to an existing session'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "attach" -d 'Attach to the current or last run in a session'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "stop" -d 'Stop an active session worker'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "compact" -d 'Compact a session\'s stored conversation (summarize older turns now)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "_worker"
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from session" -f -a "_run-turn"
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from issues" -f -a "list" -d 'List issues for a repo. Auto-detects repo from cwd\'s `origin` remote when `--repo` is omitted'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from issues" -f -a "show" -d 'Show one issue\'s full body + metadata'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from issues" -f -a "run" -d 'Convenience: run a workflow with an issue run-target. Equivalent to `rupu workflow run <name> <issue-ref>` (the run-target is a positional on `workflow run`, not a flag)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from mcp" -f -a "serve" -d 'Run the MCP server for an external MCP-aware client'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "list" -d 'List coverage targets recorded under .rupu/coverage/'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "templates" -d 'List or show bundled concern templates'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "catalog" -d 'Print the effective catalog snapshot for a target'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "show" -d 'Show the derived ledger view (touched files + assertions + findings)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "audit" -d 'Generate the coverage audit report for a target'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "gap" -d 'Show only the coverage gaps (in-scope files lacking an assertion)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "diff" -d 'Diff two runs against a target (defaults to `previous latest`)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "runs" -d 'List the runs recorded against a target (to find ids to diff)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from coverage" -f -a "rerun" -d 'Replay an agent run by id, appending a new run to the same target'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from fleet" -f -a "install" -d 'Install the stock fleet (agents + workflows) onto disk'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from fleet" -f -a "list" -d 'List the agents and workflows the stock fleet ships'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from skill" -f -a "list" -d 'List installed skills in both layers'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from skill" -f -a "show" -d 'Show one skill: frontmatter, files, fingerprints and source. Accepts `global:<name>` / `project:<name>`'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from skill" -f -a "validate" -d 'Check skills against the Agent Skills format; exit 1 on any failure'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from skill" -f -a "install" -d 'Install skills from a directory, `owner/repo`, a GitHub tree URL, or an https git URL (`#path` narrows to a folder in the repository)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from skill" -f -a "update" -d 'Re-fetch installed skills from the source they were installed from'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from findings" -f -a "schema" -d 'Print the finding report JSON Schema embedded in this build'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from findings" -f -a "export" -d 'Export findings as a report: one finding, or a project report'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from findings" -f -a "import" -d 'Attach reports written before the full profile to their findings'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from findings" -f -a "list" -d 'List findings matching a query, e.g. `severity>=high -tag:noise`'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from findings" -f -a "tag" -d 'Add or remove tags on findings'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from findings" -f -a "tags" -d 'List the tags in use, with how many findings carry each (optionally only on the findings a query selects)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from cron" -f -a "list" -d 'List every cron-triggered workflow + its schedule + next-fire time. Read-only; doesn\'t update state'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from cron" -f -a "tick" -d 'Walk all workflows, fire any whose schedule matches between the persisted `last_fired` and now. Designed to run from system cron at 1-minute granularity'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from cron" -f -a "events" -d 'Read-only inspection of event-triggered workflows'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from webhook" -f -a "serve" -d 'Run the webhook HTTP receiver in the foreground'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from cp" -f -a "serve" -d 'Start the control-plane HTTP server'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from usage" -f -a "runs" -d 'Show per-run usage rows'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from usage" -f -a "backfill" -d 'Backfill metadata sidecars for older standalone transcripts'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from completions" -f -a "print" -d 'Print a completion script for the given shell to stdout'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from completions" -f -a "install" -d 'Write the completion script to the canonical location for the given shell. If `--shell` is omitted, auto-detect from `$SHELL` (best-effort)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from host" -f -a "add" -d 'Register a remote rupu-cp host'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from host" -f -a "list" -d 'List configured hosts (local is always shown first)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from host" -f -a "remove" -d 'Remove a host by id'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from node" -f -a "enroll" -d 'Enroll a new tunnel node in the local host store and print the `rupu node --cp-url ... --token ...` command to run on the box.  The token is shown ONCE and never persisted on disk'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from node" -f -a "pull" -d 'Poll a bucket dead-drop, atomically claim jobs, run them locally, write results back, and apply queued control messages'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from __workspace" -f -a "stage" -d 'Stage a packed workspace read from stdin; print the working dir'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from __workspace" -f -a "collect" -d 'Collect the change-delta from a staged working dir; write it to stdout'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from __workspace" -f -a "discard" -d 'Best-effort discard of a staged working dir\'s scratch (no stdout)'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from __skills" -f -a "missing" -d 'Print the `hash:layer:name` refs (arguments) this host hasn\'t cached'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from __skills" -f -a "receive" -d 'Store the skills framed on stdin (`encode_stream`); print `ok <hash>` per skill'
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from __message" -f -a "list"
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from __message" -f -a "send"
complete -c rupu -n "__fish_rupu_using_subcommand help; and __fish_seen_subcommand_from __findings" -f -a "artifact" -d 'Write the stored blob `<sha256>` to stdout; nonzero exit if absent'
